
//pg 318 #4
public class Diploma {
	private String name;
	private String major;
	private String result;
	
	public Diploma(String name, String major) {
		this.name=name;
		this.major=major;
	}
	
	public String toString() {
		result = "This certifies that \n" + name + "\nhas completed a course in " + major;
		return result;
	}
}
