
public class DiplomaWithHonors extends Diploma {
	
	public DiplomaWithHonors(String name, String major) {
		super(name,major);
	}
	
	public String toString() {
		String result = super.toString() + "\n*** with Honors ***";
		return result;
	}
}
