
/*

	This class tests the Diploma and DiplomaWithHonors classes. These classes should be related through inheritance.
	(A DiplomaWithHonors IS-A Diploma)

	Should display:



	This certifies that
	Murray Smith
	has completed a course in Gardening

	This certifies that
	Lisa Smith
	has completed a course in Evolutionary Psychology
	*** with honors ***

	This certifies that
	Goji Miyao
	has completed a course in Computer Engineering

	This certifies that
	James Hinds
	has completed a course in Theoretical Physics
	*** with honors ***



*/

//Console output should be:
/*This certifies that 
Joe Smith 
has completed a course in Laywer

This certifies that 
Bob Lee
has completed a course in Doctor
*** with Honors ***

This certifies that 
Tom Jerry
has completed a course in Filmaking

This certifies that 
James Li
has completed a course in Teacher
*** with Honors ***


 * 
 * 
 * 
 * 
 */

public class DiplomaTester {

	public static void main (String[] args) {

		Diploma diploma1 = new Diploma("Joe Smith ", "Laywer");
		System.out.println(diploma1);
		System.out.println();

		Diploma diploma2 = new DiplomaWithHonors("Bob Lee", "Doctor");
		System.out.println(diploma2);
		System.out.println();

		Diploma diploma3 = new Diploma("Tom Jerry", "Filmaking");
		System.out.println(diploma3);
		System.out.println();

		Diploma diploma4 = new DiplomaWithHonors("James Li", "Teacher");
		System.out.println(diploma4);
		System.out.println();

	}

}


